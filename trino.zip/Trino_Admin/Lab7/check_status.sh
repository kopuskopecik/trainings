kubectl get pod -n minio-tenant
kubectl get pod -n metastore
kubectl get pod -n trino