kubectl apply -f hive/hive-env.yml
kubectl apply -f hive/hive-deployment.yml
kubectl apply -f hive/hive-service.yml