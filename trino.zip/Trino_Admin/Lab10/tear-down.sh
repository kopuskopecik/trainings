minikube delete
rm -r ../tls-store/