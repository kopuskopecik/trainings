kubectl get pod -n trino
kubectl get hpa -n trino
kubectl top pod -n trino