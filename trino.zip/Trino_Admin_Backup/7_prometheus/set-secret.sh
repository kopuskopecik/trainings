kubectl create secret tls certificates --cert=tls.crt --key=tls.key -n trino

kubectl create secret generic trino-auth-secret -n trino \
--from-file=password.db=./password.db \
--from-file=group.db=./group.db 

kubectl annotate secret trino-auth-secret \
  meta.helm.sh/release-name=trino-cluster \
  meta.helm.sh/release-namespace=trino \
  --namespace trino

kubectl label secret trino-auth-secret \
  app.kubernetes.io/managed-by=Helm \
  --namespace trino