
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout tls.key -out tls.crt -subj "/CN=hive-service.metastore.svc.cluster.local"


openssl pkcs12 -export -out hive-keystore.p12 -inkey tls.key -in tls.crt -name "hive-client" -passout pass:"admin123"

keytool -importkeystore -deststorepass admin123 -destkeystore hive-client-keystore.jks \
  -srckeystore hive-keystore.p12 -srcstoretype PKCS12 -srcstorepass admin123


kubectl create secret generic hive-keystore-secret \
  --from-file=hive.keystore.jks="hive-client-keystore.jks" \
  --from-literal=keystore-password="admin123" \
  -n metastore



kubectl apply -f hive/hive-env.yml
kubectl apply -f hive/hive-deployment.yml
kubectl apply -f hive/hive-service.yml