kubectl port-forward svc/myminio-console 9090:9090 -n site-a
