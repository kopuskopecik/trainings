kubectl get pods -n trino
kubectl get pods -n minio-tenant
kubectl get pods -n metastore