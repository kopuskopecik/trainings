kubectl delete namespace trino
kubectl delete namespace metastore
kubectl delete namespace minio-tenant